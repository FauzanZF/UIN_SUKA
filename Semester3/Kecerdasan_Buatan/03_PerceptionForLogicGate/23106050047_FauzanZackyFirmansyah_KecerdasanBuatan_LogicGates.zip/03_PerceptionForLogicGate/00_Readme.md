NAMA        : Fauzan Zacky Firmansyah
NNIM        : 23106050047
PRODI       : Informatika A
MATA KULIAH : Kecerdasan Buatan